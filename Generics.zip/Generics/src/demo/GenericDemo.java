package demo;

import java.util.ArrayList;
import java.util.List;

public class GenericDemo {
	
	public static<E> void show(E[] elements){
		
		for(E e:elements) {
			System.out.println(e);
		}
	}
	public static<T> void showT( List<T> l){
		System.out.println(l.size());
	}
    public static<T> void showWildcard( List<?> l){
		
	}
	public static void main(String[] args) {
		
		Integer[] number= {1,2,3,4,5};
		Character[] charac= {'a','b','c','d'};
		
		System.out.println("Number looping via Generics");
		show(number);
		System.out.println("character looping via Generics");
		show(charac);
		String[] str= {"hello","yash","when","is","kgf2","release"};
		show(str);
		
		List<Integer> l= new ArrayList<>();
		l.add(10);
		l.add(20);
		l.add(30);
		showT(l);
		List<GenericDemo> gd= new ArrayList<>();
		showWildcard(gd);	
	}
}