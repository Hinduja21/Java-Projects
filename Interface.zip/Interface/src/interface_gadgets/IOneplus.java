package interface_gadgets;

public interface IOneplus {

	String name = "Oneplus 7t";
	float price = 1000.0f;
	int ram = 6;
	int rom = 64;
	float cam_pixel = 32.0f;
	
	static void op() {
		System.out.println("Name : "+name);
		System.out.println("Price : $"+price);
		System.out.println("RAM : "+ram+" GB");
		System.out.println("Memory : "+rom+" GB");
		System.out.println("Camera pixel : "+cam_pixel+" mp");
	}
}
