package interface_gadgets;

public interface IiPhone {

	String name = "iPhone XMax";
	float price = 1500.0f;
	int ram = 8;
	int rom = 128;
	float cam_pixel = 35.5f;
	
	static void ip() {
		System.out.println("Name : "+name);
		System.out.println("Price : $"+price);
		System.out.println("RAM : "+ram+" GB");
		System.out.println("Memory : "+rom+" GB");
		System.out.println("Camera pixel : "+cam_pixel+" mp");
	}
}
