package interface_gadgets;

public class Gadgets implements IiPhone,IOneplus {

	public static void main(String[] args) {
		
		IiPhone.ip();
		System.out.println("---------------------------------------------------------------------------------");
		IOneplus.op();
	}

}
