package interface_newspapers;

public interface ITimesofIndia {
	
	 void toi(); 
}
