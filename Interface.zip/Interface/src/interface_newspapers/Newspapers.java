package interface_newspapers;

public class Newspapers implements IDeccanHerald,ITimesofIndia {
	
	public static void main(String[] args) {
		
		Newspapers n = new Newspapers();
		n.toi();
		System.out.println("---------------------------------------------------------------------------------");
		n.dh();		
	}

	@Override
	public void toi() {
		String name = "THE TIMES OF INDIA";
		int copies = 1500000;
		Float price = 7.0f;
		String type = "Color";
		
		System.out.println("Name : "+name);
		System.out.println("Price : Rs."+price);
		System.out.println("No. of copies sold per day : "+copies);
		System.out.println("Type : "+type);
	}

	@Override
	public void dh() {
		String name = "DECCAN HERALD";
		int copies = 1000000;
		Float price = 5.0f;
		String type = "Black & White";
		
		System.out.println("Name : "+name);
		System.out.println("Price : Rs."+price);
		System.out.println("No. of copies sold per day : "+copies);
		System.out.println("Type : "+type);
	}

}
