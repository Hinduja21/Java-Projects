package interface_newspapers;

public interface IDeccanHerald {

	void dh();
}
