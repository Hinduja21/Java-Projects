package interfacedemo;

public interface IAdd {
	
	public static final int a = 5;
	
	abstract void add();

}
