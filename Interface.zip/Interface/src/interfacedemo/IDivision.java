package interfacedemo;

public interface IDivision {

	void division();
}
