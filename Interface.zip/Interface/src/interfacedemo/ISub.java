package interfacedemo;

public interface ISub {

	void sub();
}
