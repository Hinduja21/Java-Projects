package interfacedemo;

public class Mathematics implements IAdd,ISub,IMultiply,IDivision {
	
	int b = 10;
	int c = 20;

	public static void main(String[] args) {
		
		System.out.println(a);
		
		Mathematics m = new Mathematics();
		m.add();
		m.sub();
		m.multiply();
		m.division();
	}

	@Override
	public void add() {
		System.out.println(b+c);
	}

	@Override
	public void sub() {
		System.out.println(c-b);
	}

	@Override
	public void multiply() {
		System.out.println(c*b);
	}

	@Override
	public void division() {
		System.out.println(c/b);
	}

}
