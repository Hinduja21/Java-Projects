package interfacedemo;

public interface IMultiply {

	void multiply();
}
