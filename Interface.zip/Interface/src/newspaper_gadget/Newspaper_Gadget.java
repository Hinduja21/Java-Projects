package newspaper_gadget;

import interface_gadgets.IiPhone;
import interface_newspapers.ITimesofIndia;

public class Newspaper_Gadget implements IiPhone,ITimesofIndia {

	public static void main(String[] args) {
		
		Newspaper_Gadget n = new Newspaper_Gadget();
		n.toi();
		System.out.println("_____________________________________________________________________________");
		IiPhone.ip();	
	}

	@Override
	public void toi() {
		String name = "THE TIMES OF INDIA";
		int copies = 1500000;
		Float price = 7.0f;
		String type = "Color";
		
		System.out.println("Name : "+name);
		System.out.println("Price : Rs."+price);
		System.out.println("No. of copies sold per day : "+copies);
		System.out.println("Type : "+type);
	}

}
